#ifndef _FIND_HEADERS_H
#define _FIND_HEADERS_H

#ifdef __cplusplus
extern "C" {
#endif

int find_header(const char *str, int size);


#ifdef __cplusplus
}
#endif
#endif
